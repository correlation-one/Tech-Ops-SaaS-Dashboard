import json, re
NM=json.load(open("naming-map.json"))
ALIASES=sorted(NM["vendor_aliases"].items(), key=lambda kv: -len(kv[0]))
NAME_MAP=NM["name_map"]
EXCL=[e.upper() for e in NM["non_saas_exclude"]]
CLASS={c["app"]:c for c in json.load(open("classification.json"))}
CLASS_NORM={k.strip().upper():v for k,v in CLASS.items()}
OVERRIDE_NONCOGS={"AIRTABLE","TWILIO","CAKE","MAILGUN"}
KNOWN=json.load(open("known_apps.json"))
PRIOR=json.load(open("prior_build.json"))
PRIOR_NORM={k.strip().upper():v for k,v in PRIOR.items()}
KNOWN_SORT=sorted(KNOWN, key=lambda s:-len(s))

def clean(desc):
    s=re.sub(r"\s+"," ",desc.split("|")[0].strip() or desc.split("|")[1].strip())
    s=re.sub(r"\s*-\s*\d{4}$","",s)
    s=re.sub(r"X{4,}[\w-]*","",s)
    return s.strip().title() or "Unknown"

def resolve(desc, amount, code="96100"):
    U=desc.upper()
    if any(e in U for e in EXCL): return None
    if "SLACK" in U or "PUMBLE" in U:
        # >=$5K is the Enterprise COGS journal; anything smaller is the internal seat line
        return "Salesforce - Slack Enterprise" if amount>=5000 else "Salesforce - Slack Internal"
    if "SALESFORCE" in U and code in ("81000","81500"):
        return "Salesforce - Other (Non-COGS)"
    for k,v in ALIASES:
        if k in U: return NAME_MAP.get(v,v)
    for a in KNOWN_SORT:
        if len(a)>3 and a.upper() in U: return NAME_MAP.get(a,a)
    n=clean(desc)
    return NAME_MAP.get(n,n)

def classify(app, code):
    if app.strip().upper() in OVERRIDE_NONCOGS: return "Non-COGS", False
    if app=="Salesforce - Slack Enterprise": return "COGS", False
    if app=="Salesforce - Slack Internal": return "Non-COGS", False
    if app=="Salesforce - Other (Non-COGS)": return "Non-COGS", False
    if app=="Salesforce - Other": return "COGS", False
    rec=CLASS_NORM.get(app.strip().upper())
    if rec:
        return ("COGS" if rec["cogs"].strip().upper()=="COGS" else "Non-COGS"), False
    pr=PRIOR_NORM.get(app.strip().upper())
    if pr: return pr["classification"], False
    return ("COGS" if code in ("53000","55000") else "Non-COGS"), True
