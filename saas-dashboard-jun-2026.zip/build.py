#!/usr/bin/env python3
"""Tech Ops SaaS Dashboard — monthly build. Regenerates data.json from the GL workbook."""
import json, pickle, sys
from collections import defaultdict
from gl import load, TABS
from resolve import resolve, classify, CLASS_NORM, PRIOR

ALWAYS={"53000","55000","96100"}; COND={"81000","81500"}
SAAS81=["OUTREACH","LINKEDIN","SALES NAVIGATOR","PROFOUND","SALESFORCE","SALES CLOUD","ZOOMINFO","TREMENDOUS"]
# GCP invoice is absent from the Apr 26 Spend tab; value carried from the verified April build.
PATCH={"2026-04":[("GCP",22812.62,"53000","Journal Entry")]}
# Codio catch-up invoice INV-1767 (Jun). Set REVERSE_CODIO=True to back it out pending Ben's reversal.
REVERSE_CODIO = "--reverse-codio" in sys.argv
CODIO_CATCHUP = 17185.79

MONTHS=list(TABS.keys()); LABELS=["Jan","Feb","Mar","Apr","May","Jun"]

spend=defaultdict(lambda: defaultdict(float))
codes={}; journal=defaultdict(bool)
for m,tab in TABS.items():
    rows=[(r["_desc"],r["_amt"],r["_code"],r.get("type",""),None) for r in load(tab)]
    rows+= [("PATCH | ",v,c,t,n) for n,v,c,t in PATCH.get(m,[])]
    for desc,val,c,ttype,forced in rows:
        if not (c in ALWAYS or (c in COND and any(s in desc for s in SAAS81))): continue
        app=forced if forced else resolve(desc,val,c)
        if app is None: continue
        if REVERSE_CODIO and m=="2026-06" and app=="Codio" and abs(val-CODIO_CATCHUP)<0.01: continue
        spend[app][m]+=val; codes.setdefault(app,c)
        if "journal" in str(ttype).lower(): journal[app]=True

def project(series):
    out=[]; 
    for i in range(len(series)):
        w=series[max(0,i-2):i+1]
        out.append(round(sum(v*(j+1) for j,v in enumerate(w))/sum(range(1,len(w)+1)),2))
    return out

apps=[]; flags=[]
for app in sorted(spend, key=lambda a:-sum(spend[a].values())):
    ser=[round(spend[app].get(m,0.0),2) for m in MONTHS]
    cl,fb=classify(app,codes[app])
    tab=CLASS_NORM.get(app.strip().upper()); pr=PRIOR.get(app,{})
    dept=(tab["dept"] if tab and tab["dept"] not in ("","#N/A") else pr.get("department")) or None
    apps.append({"name":app,"classification":cl,"department":dept,
        "journaled":bool(journal[app]) or bool(pr.get("journaled")),
        "category":pr.get("category"),"spend":ser,"projected":project(ser),
        "renewalDate":None,"renewalStatus":None,"owner":None,"annualCost":None,"billingCycle":None})
    active=[v for v in ser if abs(v)>0.005]; reasons=[]
    if fb: reasons.append("classification fell back to GL account default — needs a decision")
    if not tab: reasons.append("absent from SaaS Apps Classifcation tab")
    if len(active)==1: reasons.append("only one month of spend — one-time or new subscription?")
    if len(active)>1 and max(active)>3*sorted(active)[-2]: reasons.append("one month >3x the next — possible annual/lump")
    if max(ser,default=0)>=5000 and not journal[app]: reasons.append("payment >= $5k but not journaled")
    if active and abs(ser[-1])<0.005: reasons.append("spend stopped before the latest month")
    if reasons: flags.append({"app":app,"spend":ser,"reasons":reasons})

monthly=[]
for i,m in enumerate(MONTHS):
    tot=sum(a["spend"][i] for a in apps)
    cg=sum(a["spend"][i] for a in apps if a["classification"]=="COGS")
    monthly.append({"total":round(tot,2),"cogs":round(cg,2),"nonCogs":round(tot-cg,2)})

data={"meta":{"lastUpdated":"2026-07-29","currency":"USD",
  "sources":{"gl":"Software Spend (Google Sheet) tabs Jan–JUNE 26 Spend",
             "classification":"2026 SaaS Spend — SaaS Apps Classifcation tab"},
  "notes":["April GCP invoice absent from the Apr GL tab; carried from the verified April build.",
           ("June Codio catch-up invoice INV-1767 ($17,185.79) REVERSED pending Ben's confirmation."
            if REVERSE_CODIO else
            "June Codio is as-booked: two invoices (INV-1728 + INV-1767) totalling $35,976.27; ~$17,185.79 pending reversal.")]},
  "months":MONTHS,"monthLabels":LABELS,"monthly":monthly,"apps":apps}
json.dump(data, open("data.json","w"), indent=1)
json.dump(flags, open("review_flags.json","w"), indent=1)
print(f"apps={len(apps)}  flags={len(flags)}  codio_reversed={REVERSE_CODIO}")
for l,mo in zip(LABELS,monthly): print(f"  {l}: {mo['total']:>12,.2f}  COGS {mo['cogs']:>12,.2f}  Non {mo['nonCogs']:>12,.2f}")
