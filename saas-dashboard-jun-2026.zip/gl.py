import openpyxl, re, json
WB="software_spend.xlsx"
COL={"date":["transaction date"],"type":["transaction type"],"num":["num"],"name":["name"],
     "memo":["memo/description","description"],"acct":["account full name","full name"],
     "acctnum":["distribution account number"],"amt":["amount"]}
TABS={"2026-01":"Jan 26 spend","2026-02":"Feb 26 spend","2026-03":"Mar 26 spend",
      "2026-04":"Apr 26 Spend","2026-05":"May 26 Spend","2026-06":"JUNE 26 Spend"}
_wb=None
def wb():
    global _wb
    if _wb is None: _wb=openpyxl.load_workbook(WB, data_only=True)
    return _wb
def load(tab):
    ws=wb()[tab]; rows=[[("" if c is None else c) for c in r] for r in ws.iter_rows(values_only=True)]
    hi=[i for i,r in enumerate(rows[:8]) if any("transaction date" in str(c).strip().lower() for c in r)][0]
    hdr=[str(c).strip().lower() for c in rows[hi]]
    role={}
    for k,alts in COL.items():
        for a in alts:
            if a in hdr: role[k]=hdr.index(a); break
    out=[]
    for r in rows[hi+1:]:
        rec={k:str(r[i]) if i<len(r) else "" for k,i in role.items()}
        if not rec.get("date","").strip() and not rec.get("amt","").strip(): continue
        rec["_amt"]=amt(rec.get("amt","")); rec["_code"]=code(rec)
        rec["_desc"]=(rec.get("name","")+" | "+rec.get("memo","")).upper()
        out.append(rec)
    return out
def amt(s):
    s=str(s).replace("\\","").replace(",","").replace("$","").strip()
    if not s: return 0.0
    try: return float(s.strip("()"))*(-1 if s.startswith("(") else 1)
    except: return 0.0
def code(rec):
    m=re.match(r"^(\d{5})", str(rec.get("acctnum","")).strip())
    if m: return m.group(1)
    f=re.findall(r"\b(\d{5})\b", str(rec.get("acct","")))
    return f[-1] if f else "?"
